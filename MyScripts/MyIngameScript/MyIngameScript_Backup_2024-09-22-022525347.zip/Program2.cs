﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using VRage;
using VRage.Collections;
using VRage.Game;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ObjectBuilders.Definitions;
using VRageMath;

namespace IngameScriptCheckDamage
{
    partial class Program : MyGridProgram
    {

        private List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
        private IMyTextPanel screen;
        public Program()
        {
            Init();
        }
        public void Init()
        {
            GridTerminalSystem.GetBlocks(blocks);
            screen = (IMyTextPanel)GridTerminalSystem.GetBlockWithName("MiningDisp3");
            Runtime.UpdateFrequency = UpdateFrequency.Update100;
        }

        public void Main(string argument, UpdateType updateSource)
        {
            string s = "";
            for (int i = 0; i < blocks.Count; i++)
            {
                if (!blocks[i].IsFunctional)
                {
                    s += "Block:" + blocks[i].Name + ";" + blocks[i].CustomName + ";pos:" + blocks[i].Position + "\n";
                }
            }
            if (s == "")
            {
                screen.FontColor = Color.Green;
                screen.WriteText("Damaged blocks :\nnot found...");
            }
            else
            {
                screen.FontColor = Color.Red;
                screen.WriteText("Damaged blocks :\n" + s);
            }
        }

    }
}

namespace IngameScriptMiningCounter
{
    partial class Program : MyGridProgram
    {
        enum TankType
        {
            oxy,
            hydro,
            none
        }

        private IMyTextPanel screen;
        private IMyTextPanel screen2;
        private IMyTextPanel screen3;
        private List<IMyCargoContainer> containers = new List<IMyCargoContainer>();
        private List<IMyThrust> engines = new List<IMyThrust>();
        private List<IMyBatteryBlock> batteries = new List<IMyBatteryBlock>();
        private List<IMyGasTank> gasOxy = new List<IMyGasTank>();
        private List<IMyGasTank> gasHydro = new List<IMyGasTank>();
        private IMyAirVent vent;

        private double prevCurrentHydro = 0;

        public Program()
        {
            Init();
        }

        public void Init()
        {
            screen = (IMyTextPanel)GridTerminalSystem.GetBlockWithName("MiningDisp4");
            screen2 = (IMyTextPanel)GridTerminalSystem.GetBlockWithName("MiningDisp2");
            screen3 = (IMyTextPanel)GridTerminalSystem.GetBlockWithName("MiningDisp1");
            GridTerminalSystem.GetBlocksOfType<IMyThrust>(engines);
            engines.RemoveAll(x => !x.CustomName.Contains("MiningEngineUp"));

            GridTerminalSystem.GetBlocksOfType<IMyBatteryBlock>(batteries);
            batteries.RemoveAll(x => !x.CustomName.Contains("MiningBattery"));

            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(containers);
            containers.RemoveAll(x => !x.CustomName.Contains("MiningContainer"));

            List<IMyGasTank> gas = new List<IMyGasTank>();
            GridTerminalSystem.GetBlocksOfType<IMyGasTank>(gas);
            gas.RemoveAll(x => !x.CustomName.Contains("Mining"));
            for (int i = 0; i < gas.Count; i++)
            {
                if (GetTankType(gas[i]) == TankType.oxy)
                {
                    gasOxy.Add(gas[i]);
                }
                if (GetTankType(gas[i]) == TankType.hydro)
                {
                    gasHydro.Add(gas[i]);
                }
            }
            vent = (IMyAirVent)GridTerminalSystem.GetBlockWithName("ventMining");

            Runtime.UpdateFrequency = UpdateFrequency.Update10;
        }
        TankType GetTankType(IMyTerminalBlock theBlock)
        {
            if (theBlock is IMyGasTank)
            {
                if (theBlock.BlockDefinition.SubtypeId.Contains("Hydro"))
                    return TankType.hydro;
                else
                    return TankType.oxy;
            }
            return TankType.none;
        }
        public void Main(string argument, UpdateType updateSource)
        {
            if (argument == "r")
            {
                Init();
            }

            double volumeSum = 0;
            double volumeMax = 0;

            Dictionary<string, double> others = new Dictionary<string, double>();

            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);

                List<MyInventoryItem> inventoryItem = new List<MyInventoryItem>();
                invent.GetItems(inventoryItem);
                for (int j = 0; j < inventoryItem.Count; j++)
                {
                    if (inventoryItem[j].Type.TypeId.Contains("Component"))
                    {

                    }
                    else
                    {
                        if (!others.ContainsKey(inventoryItem[j].Type.SubtypeId))
                        {
                            others.Add(inventoryItem[j].Type.SubtypeId, 0);
                        }
                        others[inventoryItem[j].Type.SubtypeId] += ((double)inventoryItem[j].Amount);
                    }
                }
            }

            string strVolume = "Volume absolute : " + ValueToString(volumeSum * 1000) + "l / " + ValueToString(volumeMax * 1000) + "l";
            string strVolumePersent = "Volume percent : " + ((volumeSum / volumeMax) * 100).ToString("0.0") + "%";

            string OtherString = "Ores:\n";
            foreach (KeyValuePair<string, double> item in others)
            {
                OtherString += item.Key + " : " + CountToString(item.Value) + "\n";
            }

            float sumEnginesCur = 0;
            float sumEnginesMax = 0;

            for (int i = 0; i < engines.Count; i++)
            {
                sumEnginesCur += engines[i].CurrentThrust;
                sumEnginesMax += engines[i].MaxEffectiveThrust;
            }

            double Sum = 0;
            double Max = 0;
            double EnPlus = 0;
            double EnMinus = 0;

            for (int i = 0; i < batteries.Count; i++)
            {
                Max += batteries[i].MaxStoredPower;
                Sum += batteries[i].CurrentStoredPower;
                EnPlus += batteries[i].CurrentInput;
                EnMinus += batteries[i].CurrentOutput;
            }

            string strEn1 = "Energy : " + CountToString(Sum * 1000000) + "wh / " + CountToString(Max * 1000000) + "wh";
            string steEnPers = "Energy percent : " + ((Sum / Max) * 100).ToString("0.0") + "%";
            string InOut = "in : +" + CountToString(EnPlus * 1000000) + "wh" +
                           "\nout : -" + CountToString(EnMinus * 1000000) + "wh" +
                           "\ntotal : " + CountToString(((EnPlus - EnMinus) * 1000000)) + "wh";
            double time = (Max - Sum) / (EnPlus - EnMinus);
            long timeTicks = (long)(time * 3600 * 10000000);
            TimeSpan timeSpan = new TimeSpan(timeTicks);

            if (time > 0)
            {
                InOut += "\ntime to charge : " + timeSpan.ToString(@"dd\.hh\:mm\:ss");
            }
            else
            {
                InOut += "\ntime to discharge : " + timeSpan.ToString(@"dd\.hh\:mm\:ss");
            }

            double OxyCapacity = 0;
            double OxySum = 0;
            for (int i = 0; i < gasOxy.Count; i++)
            {
                OxyCapacity += gasOxy[i].Capacity;
                OxySum += gasOxy[i].FilledRatio * gasOxy[i].Capacity;
            }
            string oxyState = "oxygen : " + CountToString(OxySum) + "/" + CountToString(OxyCapacity) +
                "\nin tanks : " + ((OxySum / OxyCapacity) * 100).ToString("0.00") +
                "%\nin room : " + (vent.GetOxygenLevel() * 100).ToString("0.0000") + "%";

            double HydroCapacity = 0;
            double HydroSum = 0;
            for (int i = 0; i < gasHydro.Count; i++)
            {
                HydroCapacity += gasHydro[i].Capacity;
                HydroSum += gasHydro[i].FilledRatio * gasHydro[i].Capacity;
            }

            string chardgeState = "";
            if (prevCurrentHydro <= HydroSum)
            {
                double plusHydroPerSecond = Math.Abs(prevCurrentHydro - HydroSum) * 6;
                double hydroTime = (HydroCapacity - HydroSum) / plusHydroPerSecond;
                long timeHydroTicks = (long)(hydroTime * 10000000);
                TimeSpan timeHydroSpan = new TimeSpan(timeHydroTicks);

                chardgeState = "\nHydro charging in : " + timeHydroSpan.ToString(@"dd\.hh\:mm\:ss");
            }
            else
            {
                double minusHydroPerSecond = Math.Abs(prevCurrentHydro - HydroSum) * 6;
                double hydroTime = HydroSum / minusHydroPerSecond;
                long timeHydroTicks = (long)(hydroTime * 10000000);
                TimeSpan timeHydroSpan = new TimeSpan(timeHydroTicks);

                chardgeState = "\nHydro will end in : " + timeHydroSpan.ToString(@"dd\.hh\:mm\:ss");
            }
            prevCurrentHydro = HydroSum;

            string hydroState = "hydro : " + CountToString(HydroSum) + "/" + CountToString(HydroCapacity) +
                "\nin tanks : " + ((HydroSum / HydroCapacity) * 100).ToString("0.00") + "%" + chardgeState;

            screen3.WriteText(OtherString);
            screen2.WriteText(oxyState);
            screen.WriteText(strVolume +
                "\n" + strVolumePersent +
                "\nEngines : " + ((sumEnginesCur / sumEnginesMax) * 100).ToString("0.0") + "%" +
                "\n" + hydroState +
                "\n\n" + strEn1 + "\n" + steEnPers + "\n" + InOut);
        }

        string ValueToString(double count)
        {
            if (count >= 1000000000)
            {
                return (count / 1000000000).ToString("0.0") + "G";
            }

            if (count >= 1000000)
            {
                return (count / 1000000).ToString("0.0") + "M";
            }

            if (count >= 1000)
            {
                return (count / 1000).ToString("0.0") + "k";
            }

            return count.ToString("0.0");
        }

        string CountToString(double count)
        {
            if (count >= 1000000000)
            {
                return (count / 1000000000).ToString("0.0") + "B";
            }

            if (count >= 1000000)
            {
                return (count / 1000000).ToString("0.0") + "M";
            }

            if (count >= 1000)
            {
                return (count / 1000).ToString("0.0") + "k";
            }

            return count.ToString("0.0");
        }


    }
}

namespace IngameScriptAutoPilot
{

}

namespace IngameScript2.ServerScripts2
{
    partial class Program : MyGridProgram
    {

        private IMyTextPanel screen;
        private List<IMyCargoContainer> containers = new List<IMyCargoContainer>();
        private List<IMyShipDrill> drills = new List<IMyShipDrill>();
        private List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
        private IMyCockpit cockpit;
        private int screenIndex1 = 4;

        public Program()
        {
            Init();
        }

        private void Init()
        {
            GridTerminalSystem.GetBlocks(blocks);
            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(containers);
            GridTerminalSystem.GetBlocksOfType<IMyShipDrill>(drills);
            screen = (IMyTextPanel)GridTerminalSystem.GetBlockWithName("screen1");
            cockpit = (IMyCockpit)GridTerminalSystem.GetBlockWithName("Cock1");
        }

        public void Main(string argument, UpdateType updateSource)
        {
            Update(argument);
        }

        public void Update(string arg)
        {
            if (arg == "r")
            {
                Init();
            }
            double volumeSum = 0;
            double volumeMax = 0;
            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);
            }
            for (int i = 0; i < drills.Count; i++)
            {
                IMyInventory invent = drills[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);
            }
            string strVolumeCargoPersent = "Cargo : " + ((volumeSum / volumeMax) * 100).ToString("0.0") + "%";

            string s = "";
            for (int i = 0; i < blocks.Count; i++)
            {
                if (!blocks[i].IsFunctional)
                {
                    s += "Block:" + blocks[i].Name + ";" + blocks[i].CustomName + ";pos:" + blocks[i].Position + "\n";
                }
            }
            if (s == "")
            {
                screen.FontColor = Color.Green;
                cockpit.GetSurface(screenIndex1).WriteText("Damaged blocks :\nnot found...");
            }
            else
            {
                screen.FontColor = Color.Red;
                cockpit.GetSurface(screenIndex1).WriteText("Damaged blocks :\n" + s);
            }

            screen.WriteText(strVolumeCargoPersent);
        }

        string ValueToString(double count)
        {
            if (Math.Abs(count) >= 1000000000)
            {
                return (count / 1000000000).ToString("0.0") + "G";
            }

            if (Math.Abs(count) >= 1000000)
            {
                return (count / 1000000).ToString("0.0") + "M";
            }

            if (Math.Abs(count) >= 1000)
            {
                return (count / 1000).ToString("0.0") + "k";
            }

            return count.ToString("0.0");
        }

        string CountToString(double count)
        {
            if (Math.Abs(count) >= 1000000000)
            {
                return (count / 1000000000).ToString("0.0") + "B";
            }

            if (Math.Abs(count) >= 1000000)
            {
                return (count / 1000000).ToString("0.0") + "M";
            }

            if (Math.Abs(count) >= 1000)
            {
                return (count / 1000).ToString("0.0") + "k";
            }

            return count.ToString("0.0");
        }

    }
}

namespace IngameScript2.ServerScripts3Solars
{
    partial class Program : MyGridProgram
    {

        private enum RotorType
        {
            main,
            second
        }

        private enum State
        {
            rotationMain,
            rotationSecond,
            stop,
            init
        }

        private float StartRotorSpeed = 2;
        private float StopRotorSpeed = 0.15f;
        private float DecreaseKoef = -0.75f;

        private IMyCockpit debugSeet;
        private IMyTextPanel screen;

        private string mainRotorName = "mainRotorSolar";
        private IMyMotorStator mainMotorStator;
        private string nameRotorName1 = "secondRotor1";
        private IMyMotorStator secondMotorStator1;
        private string nameRotorName2 = "secondRotor2";
        private IMyMotorStator secondMotorStator2;

        private List<IMySolarPanel> solars = new List<IMySolarPanel>();
        private List<IMyBatteryBlock> batteries = new List<IMyBatteryBlock>();
        private State CurrentState = State.init;
        private float currentOut;
        private float GoodOut = 0.145f;

        private List<IMyLightingBlock> lamps = new List<IMyLightingBlock>();

        public Program()
        {
            Init();
        }

        private void Init()
        {
            debugSeet = (IMyCockpit)GridTerminalSystem.GetBlockWithName("debug1");
            screen = (IMyTextPanel)GridTerminalSystem.GetBlockWithName("disp1");
            GridTerminalSystem.GetBlocksOfType<IMySolarPanel>(solars);
            GridTerminalSystem.GetBlocksOfType<IMyBatteryBlock>(batteries);
            GridTerminalSystem.GetBlocksOfType<IMyLightingBlock>(lamps);
            lamps.RemoveAll(x => !x.CustomName.Contains("SolarLamp"));
            mainMotorStator = (IMyMotorStator)GridTerminalSystem.GetBlockWithName(mainRotorName);
            secondMotorStator1 = (IMyMotorStator)GridTerminalSystem.GetBlockWithName(nameRotorName1);
            secondMotorStator2 = (IMyMotorStator)GridTerminalSystem.GetBlockWithName(nameRotorName2);
            StartRotorSpeed *= -1;
            CurrentState = State.init;
            currentOut = 0;
        }

        public void Main(string argument, UpdateType updateSource)
        {
            Update(argument);
        }

        public void Update(string arg)
        {
            if (arg == "r")
            {
                Init();
            }
            float batterieskoef = batteries.Sum(x => x.CurrentStoredPower) / batteries.Sum(x => x.MaxStoredPower);
            if (batterieskoef < 0.9f)
            {
                string debug = "";
                float percent = solars.Sum(x => x.MaxOutput) / solars.Count;

                if (CurrentState == State.init)
                {
                    StopAll();
                    Rotate(RotorType.main, StartRotorSpeed);
                    CurrentState = State.rotationMain;
                }

                if (CurrentState == State.rotationSecond && currentOut > percent)
                {
                    Rotate(RotorType.second, secondMotorStator1.TargetVelocityRPM * DecreaseKoef);
                    if (Math.Abs(secondMotorStator1.TargetVelocityRPM) < StopRotorSpeed)
                    {
                        StopAll();
                        CurrentState = State.stop;
                    }
                }

                if (CurrentState == State.rotationMain && currentOut > percent)
                {
                    Rotate(RotorType.main, mainMotorStator.TargetVelocityRPM * DecreaseKoef);
                    if (Math.Abs(mainMotorStator.TargetVelocityRPM) < StopRotorSpeed)
                    {
                        StopRotor(RotorType.main);
                        CurrentState = State.rotationSecond;
                        Rotate(RotorType.second, StartRotorSpeed);
                    }
                }
                currentOut = percent;

                debug = percent.ToString("0.0000") + "\n" + CurrentState.ToString();
                debugSeet.GetSurface(0).WriteText(debug);

                if (percent < GoodOut && CurrentState == State.stop)
                {
                    MakeRedLamps();
                    Init();
                }
                if (percent >= GoodOut)
                {
                    StopAll();
                    MakeGreenLamps();
                    CurrentState = State.stop;
                }
            }
            else
            {
                StopAll();
                MakeGreenLamps();
                CurrentState = State.stop;
            }
        }

        private void MakeRedLamps()
        {
            foreach (var lamp in lamps)
            {
                lamp.Color = Color.Red;
            }
        }

        private void MakeGreenLamps()
        {
            foreach (var lamp in lamps)
            {
                lamp.Color = Color.Green;
            }
        }

        private void Rotate(RotorType rotorType, float DegreesPerSecond)
        {
            if (rotorType == RotorType.main)
            {
                mainMotorStator.TargetVelocityRPM = DegreesPerSecond;
            }
            if (rotorType == RotorType.second)
            {
                secondMotorStator1.TargetVelocityRPM = DegreesPerSecond;
                secondMotorStator2.TargetVelocityRPM = -DegreesPerSecond;
            }
        }

        private void StopAll()
        {
            currentOut = 0;
            StopRotor(RotorType.main);
            StopRotor(RotorType.second);
        }

        private void StopRotor(RotorType rotorType)
        {
            if (rotorType == RotorType.main)
            {
                mainMotorStator.TargetVelocityRPM = 0;
            }
            if (rotorType == RotorType.second)
            {
                secondMotorStator1.TargetVelocityRPM = 0;
                secondMotorStator2.TargetVelocityRPM = 0;
            }
        }

    }
}

namespace IngameScript10.MegaDrill
{
    partial class Program : MyGridProgram
    {
        /// <summary>
        /// Base class for all average types
        /// </summary>
        /// <typeparam name="T">The type of object to be averaged</typeparam>
        public abstract class AbstractAverage<T> where T : new()
        {
            /// <summary>
            /// Number of values to average
            /// </summary>
            public int Count => All.Length;

            /// <summary>
            /// Average value
            /// </summary>
            public abstract T Average { get; }

            /// <summary>
            /// Array for all values
            /// </summary>
            protected readonly T[] All;
            public int Counter
            {
                get
                {
                    return counter;
                }
                private set
                {
                    counter = value;
                    if (counter >= All.Length)
                    {
                        counter = 0;
                    }
                }
            }
            private int counter = 0;

            protected AbstractAverage(int count = 5)
            {
                All = new T[count];
            }

            /// <summary>
            /// Empty all values
            /// </summary>
            public void Clear()
            {
                for (int i = 0; i < All.Length; i++)
                {
                    All[i] = new T();
                }
            }

            /// <summary>
            /// Add next value to inner array
            /// </summary>
            public void AddNext(T value)
            {
                All[Counter++] = value;
            }

            public T this[int i] => All[i];

            public abstract T Max { get; }

        }

        /// <summary>
        /// Average realization for float-type
        /// </summary>
        public class AverageDouble : AbstractAverage<double>
        {
            public AverageDouble(int count = 5) : base(count)
            {
            }

            public override double Max
            {
                get
                {
                    return All.Max(x => x);
                }
            }

            public override double Average
            {
                get
                {
                    double sum = 0;
                    int indexes = 0;
                    foreach (double value in All)
                    {
                        if (value != 0)
                        {
                            sum += value;
                            indexes++;
                        }
                    }
                    return indexes != 0 ? sum / indexes : 0;
                }
            }
        }

        private class SCR
        {
            public readonly string name;

            public IMyTextPanel screen;
            public IMyTextSurface surface;
            private bool isInitWithPanel;

            public SCR(IMyGridTerminalSystem grid, string name)
            {
                this.name = name;
                screen = (IMyTextPanel)grid.GetBlockWithName(name);
                isInitWithPanel = true;
            }

            public SCR(IMyTextPanel textPanel, string name)
            {
                this.name = name;
                screen = textPanel;
                isInitWithPanel = true;
            }

            public SCR(IMyCockpit cockpit, int index)
            {
                this.name = index.ToString();
                surface = cockpit.GetSurface(index);
                isInitWithPanel = false;
            }

            public SCR(IMyTextSurface surface, int index)
            {
                name = index.ToString();
                this.surface = surface;
                isInitWithPanel = false;
            }

            public string Text
            {
                get
                {
                    if (isInitWithPanel)
                    {
                        return screen?.GetText();
                    }
                    else
                    {
                        return surface?.GetText();
                    }
                }
                set
                {
                    if (isInitWithPanel)
                    {
                        screen?.WriteText(value);
                    }
                    else
                    {
                        surface?.WriteText(value);
                    }
                }
            }
        }

        private DateTime TimeNow => DateTime.Now;
        private DateTime PrevTime;
        private TimeSpan DeltaTime => TimeNow - PrevTime;

        private List<SCR> screens = new List<SCR>();
        private string[] screensNames = new string[] { "disp1", "disp2", "disp3", "disp4", "disp5", "disp6", "disp7", "disp8" };
        private const string spaceString = "____________________________________________________________________________";
        private const int oneStringLength = 30;

        private List<IMyBatteryBlock> batteries = new List<IMyBatteryBlock>();
        private List<IMyGasGenerator> H2Henerators = new List<IMyGasGenerator>();
        private List<IMyCargoContainer> containers = new List<IMyCargoContainer>();
        private List<IMyCargoContainer> containersForCraft = new List<IMyCargoContainer>();

        private List<IMyProductionBlock> assemblers = new List<IMyProductionBlock>();
        private List<IMyRefinery> refineries = new List<IMyRefinery>();
        private Dictionary<string, AverageDouble> refinesTotal = new Dictionary<string, AverageDouble>();
        Dictionary<string, double> prevRefine = new Dictionary<string, double>();

        private float addCraftValue = 0.02f;

        #region addition dictionaries
        private Dictionary<string, int> componentsMinimum = new Dictionary<string, int>()
        {
            { "BulletproofGlass", 0},                     //бронестекло
            { "ComputerComponent", 0},                   //компьютер
            { "ConstructionComponent", 0},               //строительный компонент
            { "DetectorComponent", 0},                     //компоненты детектора руды
            { "Display", 0},                               //экран
            { "ExplosivesComponent", 0},                   //взрывчатка
            { "GirderComponent", 0},                      //балки
            { "GravityGeneratorComponent", 0},             //компоненты грави-генератора
            { "InteriorPlate", 0},                       //внутренняя пластина
            { "LargeTube", 0},                           //большая труба
            { "MedicalComponent", 0},                      //медицинские компоненты
            { "MetalGrid", 0},                            //решетка
            { "MotorComponent", 0},                       //мотор
            { "PowerCell", 0},                           //батарея
            { "RadioCommunicationComponent", 0},           //радио-компоненты
            { "ReactorComponent", 0},                      //реакторные компоненты
            { "SmallTube", 0},                            //малая труба
            { "SolarCell", 0},                            //солненые ячейки
            { "SteelPlate", 0},                          //стальная пластина
            { "Superconductor", 0},                       //сверхпроводник
            { "ThrustComponent", 0},                      //ионный ускоритель
        };

        private Dictionary<string, MyDefinitionId> blueprints = new Dictionary<string, MyDefinitionId>()
        {
            { "BulletproofGlass", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/BulletproofGlass")},
            { "ComputerComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ComputerComponent")},
            { "ConstructionComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ConstructionComponent")},
            { "DetectorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/DetectorComponent")},
            { "Display", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/Display")},
            { "ExplosivesComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ExplosivesComponent")},
            { "GirderComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/GirderComponent")},
            { "GravityGeneratorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/GravityGeneratorComponent")},
            { "InteriorPlate", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/InteriorPlate")},
            { "LargeTube", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/LargeTube")},
            { "MedicalComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/MedicalComponent")},
            { "MetalGrid", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/MetalGrid")},
            { "MotorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/MotorComponent")},
            { "PowerCell", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/PowerCell")},
            { "RadioCommunicationComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/RadioCommunicationComponent")},
            { "ReactorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ReactorComponent")},
            { "SmallTube", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/SmallTube")},
            { "SolarCell", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/SolarCell")},
            { "SteelPlate", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/SteelPlate")},
            { "Superconductor", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/Superconductor")},
            { "ThrustComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ThrustComponent")},
        };

        private Dictionary<string, string> blueprintsToTypes = new Dictionary<string, string>()
        {
            { "BulletproofGlass",          "BulletproofGlass"},
            { "ComputerComponent",         "Computer"},
            { "ConstructionComponent",     "Construction"},
            { "DetectorComponent",         "Detector"},
            { "Display",                   "Display"},
            { "ExplosivesComponent",       "Explosives"},
            { "GirderComponent",           "Girder"},
            { "GravityGeneratorComponent", "GravityGenerator"},
            { "InteriorPlate",             "InteriorPlate"},
            { "LargeTube",                 "LargeTube"},
            { "MedicalComponent",          "Medical"},
            { "MetalGrid",                 "MetalGrid"},
            { "MotorComponent",            "Motor"},
            { "PowerCell",                 "PowerCell"},
            { "RadioCommunicationComponent", "RadioCommunication"},
            { "ReactorComponent",          "Reactor"},
            { "SmallTube",                 "SmallTube"},
            { "SolarCell",                 "SolarCell"},
            { "SteelPlate",                "SteelPlate"},
            { "Superconductor",            "Superconductor"},
            { "ThrustComponent",           "Thrust"},
        };



        private Dictionary<string, string> typesToBlueprints = new Dictionary<string, string>()
        {
            {"BulletproofGlass"    ,"BulletproofGlass"              },
            {"Computer"            ,"ComputerComponent"              },
            {"Construction"        ,"ConstructionComponent"        },
            {"Detector"            ,"DetectorComponent"            },
            {"Display"             ,"Display"                      },
            {"Explosives"          ,"ExplosivesComponent"          },
            {"Girder"              ,"GirderComponent"              },
            {"GravityGenerator"    ,"GravityGeneratorComponent"        },
            {"InteriorPlate"       ,"InteriorPlate"                    },
            {"LargeTube"           ,"LargeTube"                         },
            {"Medical"             ,"MedicalComponent"                 },
            {"MetalGrid"           ,"MetalGrid"                        },
            {"Motor"               ,"MotorComponent"                     },
            {"PowerCell"           ,"PowerCell"                          },
            {"RadioCommunication"  ,"RadioCommunicationComponent"    },
            {"Reactor"             ,"ReactorComponent"                },
            {"SmallTube"           ,"SmallTube"                       },
            {"SolarCell"           ,"SolarCell"                       },
            {"SteelPlate"          ,"SteelPlate"                       },
            {"Superconductor"      ,"Superconductor"                      },
            {"Thrust"              ,"ThrustComponent"              },
        };
        #endregion

        public Program()
        {
            InitAll();
        }

        public void Main(string argument, UpdateType updateSource)
        {

            BatteriesInfo(argument);
            CargoInfo(argument);
            PrevTime = TimeNow;
        }

        private void InitAll()
        {
            InitScreens();
            InitBatteries();
            InitContainers();
            InitRefinery();
        }

        #region initing
        private void InitRefinery()
        {
            GridTerminalSystem.GetBlocksOfType<IMyRefinery>(refineries);
        }

        private void InitContainers()
        {
            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(containers);
            containers.RemoveAll(x => !x.CustomName.Contains("MegaDrillCont"));
            assemblers.RemoveAll(x => !x.CustomName.Contains("autoAsm"));
        }

        private void InitBatteries()
        {
            GridTerminalSystem.GetBlocksOfType<IMyBatteryBlock>(batteries);
        }

        private void InitScreens()
        {
            //foreach (string name in screensNames)
            //{
            //    screens.Add(new SCR(GridTerminalSystem, name));
            //}
            IMyCockpit myCockpit = (IMyCockpit)GridTerminalSystem.GetBlockWithName("kock");
            for (int i = 0; i < 6; i++)
            {
                screens.Add(new SCR(myCockpit, i));
            }
            screens.Add(new SCR(GridTerminalSystem, "DrillMegaDisp"));
        }
        #endregion

        public void BatteriesInfo(string arg)
        {
            double Sum = 0;
            double Max = 0;
            double EnPlus = 0;
            double EnMinus = 0;

            for (int i = 0; i < batteries.Count; i++)
            {
                if (batteries[i] != null)
                {
                    Max += batteries[i].MaxStoredPower;
                    Sum += batteries[i].CurrentStoredPower;
                    EnPlus += batteries[i].CurrentInput;
                    EnMinus += batteries[i].CurrentOutput;
                }
            }

            string strVolume = "Energy : " + CountToString(Sum * 1000000) + "w / " + CountToString(Max * 1000000) + "w";
            string strVolumePersent = "Energy percent : " + ((Sum / Max) * 100).ToString("0.0") + "%";
            string InOut = "in : +" + CountToString(EnPlus * 1000000) + "wh" +
                           "\nout : -" + CountToString(EnMinus * 1000000) + "wh" +
                           "\ntotal : " + CountToString(((EnPlus - EnMinus) * 1000000)) + "wh";
            double time = (Max - Sum) / (EnPlus - EnMinus);

            long timeTicks = (long)(time * 3600 * 10000000);
            TimeSpan timeSpan = new TimeSpan(timeTicks);

            if ((Sum / Max) * 100 < 99)
            {
                if (time > 0)
                {
                    InOut += "\ntime to charge : " + timeSpan.ToString(@"dd\.hh\:mm\:ss");
                }
                else
                {
                    double timeToDiscarge = (Sum) / (EnPlus - EnMinus);
                    long timeTicksToDiscarge = (long)(timeToDiscarge * 3600 * 10000000);
                    TimeSpan timeSpanToDiscarge = new TimeSpan(timeTicks);
                    InOut += "\ntime to discharge : " + timeSpanToDiscarge.ToString(@"dd\.hh\:mm\:ss");
                }
            }
            else
            {
                InOut += "\nBatteries charged";
            }

            screens[0].Text = strVolume + "\n" + strVolumePersent + "\n" + InOut + "\n";
        }

        private void CargoInfo(string arg)
        {
            screens[1].Text = "0";

            double volumeSum = 0;
            double volumeMax = 0;
            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);
            }

            screens[1].Text = "1";

            Dictionary<string, double> components = new Dictionary<string, double>();
            Dictionary<string, double> others = new Dictionary<string, double>();

            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);

                List<MyInventoryItem> inventoryItem = new List<MyInventoryItem>();
                invent.GetItems(inventoryItem);
                for (int j = 0; j < inventoryItem.Count; j++)
                {
                    if (inventoryItem[j].Type.TypeId.Contains("Component"))
                    {
                        string key = inventoryItem[j].Type.SubtypeId;
                        if (!components.ContainsKey(key))
                        {
                            components.Add(key, 0);
                        }
                        components[key] += ((double)inventoryItem[j].Amount);
                    }
                    else
                    {
                        if (inventoryItem[j].Type.TypeId.Contains("Ingot") || inventoryItem[j].Type.TypeId.Contains("Ore"))
                        {
                            string key = inventoryItem[j].Type.TypeId.Substring(16) + inventoryItem[j].Type.SubtypeId;
                            if (!others.ContainsKey(key))
                            {
                                others.Add(key, 0);
                            }
                            others[key] += ((double)inventoryItem[j].Amount);
                        }
                    }
                }
            }

            screens[1].Text = "2";

            Dictionary<string, double> production = new Dictionary<string, double>();

            foreach (IMyAssembler asm in assemblers)
            {
                List<MyProductionItem> queue = new List<MyProductionItem>();
                asm.GetQueue(queue);
                foreach (MyProductionItem item in queue)
                {
                    string key = item.BlueprintId.SubtypeName;
                    if (!production.ContainsKey(key))
                    {
                        production.Add(key, 0);
                    }
                    production[key] += ((int)item.Amount);
                }

                IMyInventory asmInvent = asm.OutputInventory;
                List<MyInventoryItem> inventoryItems = new List<MyInventoryItem>();
                asmInvent.GetItems(inventoryItems);

                foreach (var item in inventoryItems)
                {
                    if (item.Type.TypeId.Contains("Component"))
                    {
                        string key = item.Type.SubtypeId;
                        if (!components.ContainsKey(key))
                        {
                            components.Add(key, 0);
                        }
                        components[key] += ((double)item.Amount);

                        IMyInventory inventTo = containersForCraft.FirstOrDefault(x =>
                        {
                            return (x.GetInventory().MaxVolume - x.GetInventory().CurrentVolume) > item.Amount;
                        })?.GetInventory();
                        asmInvent.TransferItemTo(inventTo, item);

                    }
                }
            }

            screens[1].Text = "3";

            foreach (KeyValuePair<string, int> item in componentsMinimum)
            {
                screens[1].Text = "3.0";

                int prodValue = 0;
                if (production.ContainsKey(item.Key))
                {
                    prodValue = (int)production[item.Key];
                }

                screens[1].Text = "3.1 " + item.Key;

                int cargoValue = 0;
                if (components.ContainsKey(blueprintsToTypes[item.Key]))
                {
                    cargoValue = (int)components[blueprintsToTypes[item.Key]];
                }
                else
                {
                    components.Add(blueprintsToTypes[item.Key], 0);
                }

                screens[1].Text = "3.2 " + blueprintsToTypes[item.Key];

                if (prodValue + cargoValue < item.Value)
                {
                    foreach (IMyAssembler ams in assemblers)
                    {
                        ams.AddQueueItem(blueprints[item.Key], (double)Math.Truncate(addCraftValue * item.Value));
                    }
                }

                screens[1].Text = "3.3 " + blueprints[item.Key];
            }

            screens[1].Text = "4";

            string strCargo = "Cargo absolute : " + ValueToString(volumeSum * 1000) + "l / " + ValueToString(volumeMax * 1000) + "l";
            string strCargoPersent = "\nCargo percent : " + ((volumeSum / volumeMax) * 100).ToString("0.0") + "%";

            screens[1].Text = "5";

            screens[3].Text = /*strCargo +*/ strCargoPersent;
            screens[6].Text = ((volumeSum / volumeMax) * 100).ToString("0.0") + "%";
        }

        enum TankType
        {
            oxy,
            hydro,
            none
        }
        TankType GetTankType(IMyTerminalBlock theBlock)
        {
            if (theBlock is IMyGasTank)
            {
                if (theBlock.BlockDefinition.SubtypeId.Contains("Hydro"))
                    return TankType.hydro;
                else
                    return TankType.oxy;
            }
            return TankType.none;
        }

        string ValueToString(double count)
        {
            if (Math.Abs(count) >= 1000000000)
            {
                return (count / 1000000000).ToString("0.0") + "G";
            }

            if (Math.Abs(count) >= 1000000)
            {
                return (count / 1000000).ToString("0.0") + "M";
            }

            if (Math.Abs(count) >= 1000)
            {
                return (count / 1000).ToString("0.0") + "k";
            }

            return count.ToString("0.0");
        }

        string CountToString(double count, string roundto = "0.0")
        {
            if (Math.Abs(count) >= 1000000000)
            {
                return (count / 1000000000).ToString(roundto) + "B";
            }

            if (Math.Abs(count) >= 1000000)
            {
                return (count / 1000000).ToString(roundto) + "M";
            }

            if (Math.Abs(count) >= 1000)
            {
                return (count / 1000).ToString(roundto) + "k";
            }

            if (Math.Abs(count) == Math.Abs(Math.Truncate(count)))
            {
                return count.ToString();
            }

            return count.ToString(roundto);
        }

        private double Clamp(double x, double min, double max)
        {
            return (x < min) ? min : ((x > max) ? max : x);
        }

    }
}

namespace IngameScript10.DynamicGyros
{

    partial class Program : MyGridProgram
    {

        private float minGyroPower = 0.01f;

        private float maxGyroPower = 0.5f;

        private List<IMyGyro> gyros = new List<IMyGyro>();
        private List<IMyCargoContainer> containers = new List<IMyCargoContainer>();

        public Program()
        {
            InitAll();

        }

        private void InitAll()
        {
            InitGyros();
            InitContainers();
        }

        private void InitContainers()
        {
            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(containers);
        }

        private void InitGyros()
        {
            GridTerminalSystem.GetBlocksOfType<IMyGyro>(gyros);
            gyros.RemoveAll(x => !x.CustomName.Contains("gyroWelder"));
        }

        public void Main(string argument, UpdateType updateSource)
        {
            BalanceGyros();
        }

        private void BalanceGyros()
        {
            double volumeSum = 0;
            double volumeMax = 0;
            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);
            }
            double percent = (volumeSum / volumeMax);

            foreach (IMyGyro gyro in gyros)
            {
                gyro.GyroPower = (float)(minGyroPower + (percent * (1 - minGyroPower))) * maxGyroPower;
            }

        }
    }
}

namespace IngameScript10.EmptyProcess
{
    partial class Program : MyGridProgram
    {
        private string thisProgramBlockName = "";

        private IMyProgrammableBlock thisBlock;

        #region counter

        private int counter = 0;

        #endregion

        public Program()
        {
            InitAll();
        }

        private void InitAll()
        {
            InitThis();
        }

        private void InitThis()
        {
            thisBlock = (IMyProgrammableBlock)GridTerminalSystem.GetBlockWithName(thisProgramBlockName);
        }

        public void Main(string argument, UpdateType updateSource)
        {
            Processing();
        }

        private void Processing()
        {
            counter++;
            if (counter > 3)
            {
                counter = 0;
            }
            string dots = "";
            for (int i = 0; i < counter; i++)
            {
                dots += ".";
            }
            thisBlock.GetSurface(0).WriteText("processing" + dots);
        }
    }
}

namespace IngameScript10.TS
{
    partial class Program : MyGridProgram
    {
        /// <summary>
        /// Base class for all average types
        /// </summary>
        /// <typeparam name="T">The type of object to be averaged</typeparam>
        public abstract class AbstractAverage<T> where T : new()
        {
            /// <summary>
            /// Number of values to average
            /// </summary>
            public int Count => All.Length;

            /// <summary>
            /// Average value
            /// </summary>
            public abstract T Average { get; }

            /// <summary>
            /// Array for all values
            /// </summary>
            protected readonly T[] All;
            public int Counter
            {
                get
                {
                    return counter;
                }
                private set
                {
                    counter = value;
                    if (counter >= All.Length)
                    {
                        counter = 0;
                    }
                }
            }
            private int counter = 0;

            protected AbstractAverage(int count = 5)
            {
                All = new T[count];
            }

            /// <summary>
            /// Empty all values
            /// </summary>
            public void Clear()
            {
                for (int i = 0; i < All.Length; i++)
                {
                    All[i] = new T();
                }
            }

            /// <summary>
            /// Add next value to inner array
            /// </summary>
            public void AddNext(T value)
            {
                All[Counter++] = value;
            }

            public T this[int i] => All[i];

            public abstract T Max { get; }

        }

        /// <summary>
        /// Average realization for float-type
        /// </summary>
        public class AverageDouble : AbstractAverage<double>
        {
            public AverageDouble(int count = 5) : base(count)
            {
            }

            public override double Max
            {
                get
                {
                    return All.Max(x => x);
                }
            }

            public override double Average
            {
                get
                {
                    double sum = 0;
                    int indexes = 0;
                    foreach (double value in All)
                    {
                        if (value != 0)
                        {
                            sum += value;
                            indexes++;
                        }
                    }
                    return indexes != 0 ? sum / indexes : 0;
                }
            }
        }

        private class SCR
        {
            public readonly string name;

            public IMyTextPanel screen;
            public IMyTextSurface surface;
            private bool isInitWithPanel;

            public SCR(IMyGridTerminalSystem grid, string name)
            {
                this.name = name;
                screen = (IMyTextPanel)grid.GetBlockWithName(name);
                isInitWithPanel = true;
            }

            public SCR(IMyTextPanel textPanel, string name)
            {
                this.name = name;
                screen = textPanel;
                isInitWithPanel = true;
            }

            public SCR(IMyCockpit cockpit, int index)
            {
                this.name = index.ToString();
                surface = cockpit.GetSurface(index);
                isInitWithPanel = false;
            }

            public SCR(IMyTextSurface surface, int index)
            {
                name = index.ToString();
                this.surface = surface;
                isInitWithPanel = false;
            }

            public string Text
            {
                get
                {
                    if (isInitWithPanel)
                    {
                        return screen?.GetText();
                    }
                    else
                    {
                        return surface?.GetText();
                    }
                }
                set
                {
                    if (isInitWithPanel)
                    {
                        screen?.WriteText(value);
                    }
                    else
                    {
                        surface?.WriteText(value);
                    }
                }
            }
        }

        private DateTime TimeNow => DateTime.Now;
        private DateTime PrevTime;
        private TimeSpan DeltaTime => TimeNow - PrevTime;

        private List<SCR> screens = new List<SCR>();
        private string[] screensNames = new string[] { "TS_disp1", "TS_disp2", "TS_disp3", "TS_disp4", "TS_disp5", "TS_disp6", "TS_disp7", "TS_disp8", "TS_disp9" };
        private const string spaceString = "____________________________________________________________________________";
        private const int oneStringLength = 30;

        private List<IMyBatteryBlock> batteries = new List<IMyBatteryBlock>();
        private List<IMyGasGenerator> H2Henerators = new List<IMyGasGenerator>();
        private List<IMyCargoContainer> containers = new List<IMyCargoContainer>();
        private List<IMyCargoContainer> containersForCraft = new List<IMyCargoContainer>();

        private List<IMyProductionBlock> assemblers = new List<IMyProductionBlock>();
        private List<IMyRefinery> refineries = new List<IMyRefinery>();
        private Dictionary<string, AverageDouble> refinesTotal = new Dictionary<string, AverageDouble>();
        Dictionary<string, double> prevRefine = new Dictionary<string, double>();

        private float addCraftValue = 0.02f;

        #region addition dictionaries
        private Dictionary<string, int> componentsMinimum = new Dictionary<string, int>()
        {
            { "BulletproofGlass", 20000},                     //бронестекло
            { "ComputerComponent", 100000},                   //компьютер
            { "ConstructionComponent", 100000},               //строительный компонент
            { "DetectorComponent", 1000},                     //компоненты детектора руды
            { "Display", 1000},                               //экран
            { "ExplosivesComponent", 1000},                   //взрывчатка
            { "GirderComponent", 20000},                      //балки
            { "GravityGeneratorComponent", 1000},             //компоненты грави-генератора
            { "InteriorPlate", 100000},                       //внутренняя пластина
            { "LargeTube", 100000},                           //большая труба
            { "MedicalComponent", 1000},                      //медицинские компоненты
            { "MetalGrid", 50000},                            //решетка
            { "MotorComponent", 50000},                       //мотор
            { "PowerCell", 100000},                           //батарея
            { "RadioCommunicationComponent", 1000},           //радио-компоненты
            { "ReactorComponent", 2000},                      //реакторные компоненты
            { "SmallTube", 50000},                            //малая труба
            { "SolarCell", 10000},                            //солненые ячейки
            { "SteelPlate", 200000},                          //стальная пластина
            { "Superconductor", 50000},                       //сверхпроводник
            { "ThrustComponent", 50000},                      //ионный ускоритель
        };

        private Dictionary<string, MyDefinitionId> blueprints = new Dictionary<string, MyDefinitionId>()
        {
            { "BulletproofGlass", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/BulletproofGlass")},
            { "ComputerComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ComputerComponent")},
            { "ConstructionComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ConstructionComponent")},
            { "DetectorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/DetectorComponent")},
            { "Display", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/Display")},
            { "ExplosivesComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ExplosivesComponent")},
            { "GirderComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/GirderComponent")},
            { "GravityGeneratorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/GravityGeneratorComponent")},
            { "InteriorPlate", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/InteriorPlate")},
            { "LargeTube", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/LargeTube")},
            { "MedicalComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/MedicalComponent")},
            { "MetalGrid", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/MetalGrid")},
            { "MotorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/MotorComponent")},
            { "PowerCell", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/PowerCell")},
            { "RadioCommunicationComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/RadioCommunicationComponent")},
            { "ReactorComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ReactorComponent")},
            { "SmallTube", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/SmallTube")},
            { "SolarCell", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/SolarCell")},
            { "SteelPlate", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/SteelPlate")},
            { "Superconductor", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/Superconductor")},
            { "ThrustComponent", MyDefinitionId.Parse("MyObjectBuilder_BlueprintDefinition/ThrustComponent")},
        };

        private Dictionary<string, string> blueprintsToTypes = new Dictionary<string, string>()
        {
            { "BulletproofGlass",          "BulletproofGlass"},
            { "ComputerComponent",         "Computer"},
            { "ConstructionComponent",     "Construction"},
            { "DetectorComponent",         "Detector"},
            { "Display",                   "Display"},
            { "ExplosivesComponent",       "Explosives"},
            { "GirderComponent",           "Girder"},
            { "GravityGeneratorComponent", "GravityGenerator"},
            { "InteriorPlate",             "InteriorPlate"},
            { "LargeTube",                 "LargeTube"},
            { "MedicalComponent",          "Medical"},
            { "MetalGrid",                 "MetalGrid"},
            { "MotorComponent",            "Motor"},
            { "PowerCell",                 "PowerCell"},
            { "RadioCommunicationComponent", "RadioCommunication"},
            { "ReactorComponent",          "Reactor"},
            { "SmallTube",                 "SmallTube"},
            { "SolarCell",                 "SolarCell"},
            { "SteelPlate",                "SteelPlate"},
            { "Superconductor",            "Superconductor"},
            { "ThrustComponent",           "Thrust"},
        };

        private Dictionary<string, string> typesToBlueprints = new Dictionary<string, string>()
        {
            {"BulletproofGlass"    ,"BulletproofGlass"              },
            {"Computer"            ,"ComputerComponent"              },
            {"Construction"        ,"ConstructionComponent"        },
            {"Detector"            ,"DetectorComponent"            },
            {"Display"             ,"Display"                      },
            {"Explosives"          ,"ExplosivesComponent"          },
            {"Girder"              ,"GirderComponent"              },
            {"GravityGenerator"    ,"GravityGeneratorComponent"        },
            {"InteriorPlate"       ,"InteriorPlate"                    },
            {"LargeTube"           ,"LargeTube"                         },
            {"Medical"             ,"MedicalComponent"                 },
            {"MetalGrid"           ,"MetalGrid"                        },
            {"Motor"               ,"MotorComponent"                     },
            {"PowerCell"           ,"PowerCell"                          },
            {"RadioCommunication"  ,"RadioCommunicationComponent"    },
            {"Reactor"             ,"ReactorComponent"                },
            {"SmallTube"           ,"SmallTube"                       },
            {"SolarCell"           ,"SolarCell"                       },
            {"SteelPlate"          ,"SteelPlate"                       },
            {"Superconductor"      ,"Superconductor"                      },
            {"Thrust"              ,"ThrustComponent"              },
        };
        #endregion

        public Program()
        {
            InitAll();
        }

        public void Main(string argument, UpdateType updateSource)
        {

            BatteriesInfo(argument);
            CargoInfo(argument);
            PrevTime = TimeNow;
        }

        private void InitAll()
        {
            InitScreens();
            InitBatteries();
            InitContainers();
            InitRefinery();
        }

        #region initing
        private void InitRefinery()
        {
            GridTerminalSystem.GetBlocksOfType<IMyRefinery>(refineries);
        }

        private void InitContainers()
        {
            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(containers);
            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(containersForCraft);
            containersForCraft.RemoveAll(x => !x.CustomName.Contains("TS_cont"));
            GridTerminalSystem.GetBlocksOfType<IMyProductionBlock>(assemblers);
            GridTerminalSystem.GetBlocksOfType<IMyGasGenerator>(H2Henerators);
            assemblers.RemoveAll(x => !x.CustomName.Contains("TS_autoAsm"));
        }

        private void InitBatteries()
        {
            GridTerminalSystem.GetBlocksOfType<IMyBatteryBlock>(batteries);
        }

        private void InitScreens()
        {
            //foreach (string name in screensNames)
            //{
            //    screens.Add(new SCR(GridTerminalSystem, name));
            //}

            foreach (string name in screensNames)
            {
                screens.Add(new SCR(GridTerminalSystem, name));
            }
            IMyCockpit myCockpit = (IMyCockpit)GridTerminalSystem.GetBlockWithName("TS_kock");
            screens.Add(new SCR(myCockpit, 0));
        }
        #endregion

        public void BatteriesInfo(string arg)
        {
            double Sum = 0;
            double Max = 0;
            double EnPlus = 0;
            double EnMinus = 0;

            for (int i = 0; i < batteries.Count; i++)
            {
                if (batteries[i] != null)
                {
                    Max += batteries[i].MaxStoredPower;
                    Sum += batteries[i].CurrentStoredPower;
                    EnPlus += batteries[i].CurrentInput;
                    EnMinus += batteries[i].CurrentOutput;
                }
            }

            string strVolume = "Energy : " + CountToString(Sum * 1000000) + "w / " + CountToString(Max * 1000000) + "w";
            string strVolumePersent = "Energy percent : " + ((Sum / Max) * 100).ToString("0.0") + "%";
            string InOut = "in : +" + CountToString(EnPlus * 1000000) + "wh" +
                           "\nout : -" + CountToString(EnMinus * 1000000) + "wh" +
                           "\ntotal : " + CountToString(((EnPlus - EnMinus) * 1000000)) + "wh";
            double time = (Max - Sum) / (EnPlus - EnMinus);

            long timeTicks = (long)(time * 3600 * 10000000);
            TimeSpan timeSpan = new TimeSpan(timeTicks);

            if ((Sum / Max) * 100 < 99)
            {
                if (time > 0)
                {
                    InOut += "\ntime to charge : " + timeSpan.ToString(@"dd\.hh\:mm\:ss");
                }
                else
                {
                    double timeToDiscarge = (Sum) / (EnPlus - EnMinus);
                    long timeTicksToDiscarge = (long)(timeToDiscarge * 3600 * 10000000);
                    TimeSpan timeSpanToDiscarge = new TimeSpan(timeTicks);
                    InOut += "\ntime to discharge : " + timeSpanToDiscarge.ToString(@"dd\.hh\:mm\:ss");
                }
            }
            else
            {
                InOut += "\nBatteries charged";
            }

            screens[0].Text = strVolume + "\n" + strVolumePersent + "\n" + InOut + "\n";
        }

        private void CargoInfo(string arg)
        {
            screens[1].Text = "0";

            double volumeSum = 0;
            double volumeMax = 0;
            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);
            }

            //screens[1].Text = "1";

            Dictionary<string, double> components = new Dictionary<string, double>();
            Dictionary<string, double> others = new Dictionary<string, double>();

            for (int i = 0; i < containers.Count; i++)
            {
                IMyInventory invent = containers[i].GetInventory();
                volumeMax += ((double)invent.MaxVolume);
                volumeSum += ((double)invent.CurrentVolume);

                List<MyInventoryItem> inventoryItem = new List<MyInventoryItem>();
                invent.GetItems(inventoryItem);
                for (int j = 0; j < inventoryItem.Count; j++)
                {
                    if (inventoryItem[j].Type.TypeId.Contains("Component"))
                    {
                        string key = inventoryItem[j].Type.SubtypeId;
                        if (!components.ContainsKey(key))
                        {
                            components.Add(key, 0);
                        }
                        components[key] += ((double)inventoryItem[j].Amount);
                    }
                    else
                    {
                        if (inventoryItem[j].Type.TypeId.Contains("Ingot") || inventoryItem[j].Type.TypeId.Contains("Ore"))
                        {
                            string key = inventoryItem[j].Type.TypeId.Substring(16) + inventoryItem[j].Type.SubtypeId;
                            if (!others.ContainsKey(key))
                            {
                                others.Add(key, 0);
                            }
                            others[key] += ((double)inventoryItem[j].Amount);
                        }
                    }
                }
            }

            //screens[1].Text = "2";

            Dictionary<string, double> production = new Dictionary<string, double>();

            foreach (IMyAssembler asm in assemblers)
            {
                List<MyProductionItem> queue = new List<MyProductionItem>();
                asm.GetQueue(queue);
                foreach (MyProductionItem item in queue)
                {
                    string key = item.BlueprintId.SubtypeName;
                    if (!production.ContainsKey(key))
                    {
                        production.Add(key, 0);
                    }
                    production[key] += ((int)item.Amount);
                }

                IMyInventory asmInvent = asm.OutputInventory;
                List<MyInventoryItem> inventoryItems = new List<MyInventoryItem>();
                asmInvent.GetItems(inventoryItems);

                foreach (var item in inventoryItems)
                {
                    if (item.Type.TypeId.Contains("Component"))
                    {
                        string key = item.Type.SubtypeId;
                        if (!components.ContainsKey(key))
                        {
                            components.Add(key, 0);
                        }
                        components[key] += ((double)item.Amount);

                        IMyInventory inventTo = containersForCraft.FirstOrDefault(x =>
                        {
                            return (x.GetInventory().MaxVolume - x.GetInventory().CurrentVolume) > item.Amount;
                        })?.GetInventory();
                        asmInvent.TransferItemTo(inventTo, item);

                    }
                }
            }

            //screens[1].Text = "3";

            foreach (KeyValuePair<string, int> item in componentsMinimum)
            {
                //screens[1].Text = "3.0";

                int prodValue = 0;
                if (production.ContainsKey(item.Key))
                {
                    prodValue = (int)production[item.Key];
                }

                //screens[1].Text = "3.1 " + item.Key;

                int cargoValue = 0;
                if (components.ContainsKey(blueprintsToTypes[item.Key]))
                {
                    cargoValue = (int)components[blueprintsToTypes[item.Key]];
                }
                else
                {
                    components.Add(blueprintsToTypes[item.Key], 0);
                }

                //screens[1].Text = "3.2 " + blueprintsToTypes[item.Key];

                if (prodValue + cargoValue < item.Value)
                {
                    foreach (IMyAssembler ams in assemblers)
                    {
                        ams.AddQueueItem(blueprints[item.Key], (double)Math.Truncate(addCraftValue * item.Value));
                    }
                }

                //screens[1].Text = "3.3 " + blueprints[item.Key];
            }

            //screens[1].Text = "4";

            string strCargo = "Cargo absolute : " + ValueToString(volumeSum * 1000) + "l / " + ValueToString(volumeMax * 1000) + "l";
            string strCargoPersent = "\nCargo percent : " + ((volumeSum / volumeMax) * 100).ToString("0.0") + "%";

            string ComponentsString = "Components:\n";
            List<KeyValuePair<string, double>> compList = components.OrderBy(x => x.Key).ToList();
            foreach (KeyValuePair<string, double> item in compList)
            {
                string str = item.Key + ":" + CountToString(item.Value, "0.000");
                str += spaceString.Substring(0, (int)Clamp(oneStringLength - str.Length, 0, oneStringLength - str.Length));
                if (typesToBlueprints.ContainsKey(item.Key))
                {
                    if (production.ContainsKey(typesToBlueprints[item.Key]))
                    {
                        str += "| In production:" + CountToString(production[typesToBlueprints[item.Key]], "0.000");
                    }
                }
                ComponentsString += str + "\n";
            }
            string OresString = "";
            string IngotsString = "";
            foreach (KeyValuePair<string, double> item in others)
            {
                if (item.Key.Contains("Ore"))
                {
                    OresString = item.Key + ":" + CountToString(item.Value) + "\n" + OresString;
                }
                else
                {
                    IngotsString = IngotsString + item.Key + ":" + CountToString(item.Value) + "\n";
                }
            }

            //screens[1].Text = "5";

            screens[1].Text = OresString;
            screens[5].Text = IngotsString;
            screens[6].Text = strCargo + strCargoPersent;
            screens[7].Text = ComponentsString;
        }

        enum TankType
        {
            oxy,
            hydro,
            none
        }
        TankType GetTankType(IMyTerminalBlock theBlock)
        {
            if (theBlock is IMyGasTank)
            {
                if (theBlock.BlockDefinition.SubtypeId.Contains("Hydro"))
                    return TankType.hydro;
                else
                    return TankType.oxy;
            }
            return TankType.none;
        }

        string ValueToString(double count)
        {
            if (Math.Abs(count) >= 1000000000)
            {
                return (count / 1000000000).ToString("0.0") + "G";
            }

            if (Math.Abs(count) >= 1000000)
            {
                return (count / 1000000).ToString("0.0") + "M";
            }

            if (Math.Abs(count) >= 1000)
            {
                return (count / 1000).ToString("0.0") + "k";
            }

            return count.ToString("0.0");
        }

        string CountToString(double count, string roundto = "0.0")
        {
            if (Math.Abs(count) >= 1000000000)
            {
                return (count / 1000000000).ToString(roundto) + "B";
            }

            if (Math.Abs(count) >= 1000000)
            {
                return (count / 1000000).ToString(roundto) + "M";
            }

            if (Math.Abs(count) >= 1000)
            {
                return (count / 1000).ToString(roundto) + "k";
            }

            if (Math.Abs(count) == Math.Abs(Math.Truncate(count)))
            {
                return count.ToString();
            }

            return count.ToString(roundto);
        }

        private double Clamp(double x, double min, double max)
        {
            return (x < min) ? min : ((x > max) ? max : x);
        }

    }
}

namespace IngameScript10.RenderingTry
{
    partial class Program : MyGridProgram
    {
        private class VirtualScreen
        {
            public int sWidth = 17;
            public int sHeight = 50;

            public float aspect => (float)sWidth / sHeight;
            public float pixelAspect = 1;

            public char[,] innerScreen;

            public string gradient = " .:!/r(l1Z4H9W8$@";

            public VirtualScreen()
            {
                innerScreen = new char[sWidth, sHeight];
            }

            public string GetCurrentScreen()
            {
                string result = "";
                for (int i = 0; i < sWidth; i++)
                {
                    for (int j = 0; j < sHeight; j++)
                    {
                        result += innerScreen[i, j];
                    }
                    result += "\n";
                }
                return result;
            }
        }

        private class SCR
        {
            public readonly string name;

            public IMyTextPanel screen;
            public IMyTextSurface surface;
            private bool isInitWithPanel;

            public SCR(IMyGridTerminalSystem grid, string name)
            {
                this.name = name;
                screen = (IMyTextPanel)grid.GetBlockWithName(name);
                isInitWithPanel = true;
            }

            public SCR(IMyTextPanel textPanel, string name)
            {
                this.name = name;
                screen = textPanel;
                isInitWithPanel = true;
            }

            public SCR(IMyCockpit cockpit, int index)
            {
                this.name = index.ToString();
                surface = cockpit.GetSurface(index);
                isInitWithPanel = false;
            }

            public SCR(IMyTextSurface surface, int index)
            {
                name = index.ToString();
                this.surface = surface;
                isInitWithPanel = false;
            }

            public string Text
            {
                get
                {
                    if (isInitWithPanel)
                    {
                        return screen?.GetText();
                    }
                    else
                    {
                        return surface?.GetText();
                    }
                }
                set
                {
                    if (isInitWithPanel)
                    {
                        screen?.WriteText(value);
                    }
                    else
                    {
                        surface?.WriteText(value);
                    }
                }
            }
        }

        private SCR mainScr;

        private VirtualScreen VS;
        private IMyTimerBlock timerBlock;
        public Program()
        {
            InitAll();
        }

        private void InitAll()
        {
            InitScreen();
            timerBlock = (IMyTimerBlock)GridTerminalSystem.GetBlockWithName("timer2");
        }

        private void InitScreen()
        {
            mainScr = new SCR(GridTerminalSystem, "TS_disp4");
            VS = new VirtualScreen();
        }

        public void Main(string argument, UpdateType updateSource)
        {
            Rendering();
            UpdateScreen();
            timerBlock.ApplyAction("TriggerNow");
        }

        private void UpdateScreen()
        {
            mainScr.Text = VS.GetCurrentScreen();
        }

        private void Rendering()
        {
            for (int i = 0; i < VS.sWidth; i++)
            {
                for (int j = 0; j < VS.sHeight; j++)
                {
                    float x = (float)i / VS.sWidth * 2.0f - 1.0f;
                    float y = (float)j / VS.sHeight * 2.0f - 1.0f;

                    x *= VS.aspect * VS.pixelAspect;

                    char pixel = ' ';
                    if (x * x + y * y < Math.Sin(DateTime.Now.Second))
                    {
                        pixel = VS.gradient[15];
                    }
                    VS.innerScreen[i, j] = pixel;

                }
            }

        }

    }
}

